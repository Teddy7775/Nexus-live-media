Upload the CONTENTS of this folder to public_html on Hostinger.
(If you work from the zip files in release/: extract my-corner-of-the-world_public_html.zip and then every
 my-corner-of-the-world_downloads_N.zip into the same folder; those hold the EPUB downloads.)
Then copy api/config.sample.php to api/config.php and fill it in (owner email, mail_from).
Full instructions: my-corner-of-the-world/README.md
